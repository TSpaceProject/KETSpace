<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($topic): ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($topic->title); ?></h1>
                    <form action="<?php echo e(route('results.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div>
                            <input type="hidden" name="topic_id" value="<?php echo e($topic->id); ?>">
                            <?php $__currentLoopData = $topic->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <?php echo e($question->question_text); ?>

                                    <input type="hidden" name="question_id[]" value="<?php echo e($question->id); ?>">
                                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <input type="checkbox" name="option[<?php echo e($question->id); ?>][<?php echo e($option->id); ?>]"
                                                   value="<?php echo e($option->correct); ?>">
                                            <?php echo e($option->option); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <a href="<?php echo e(route('results.show', $topic->id)); ?>"><input type="submit" value="Submit"
                                                                               class="btn btn-success mt-3"></a>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <h1>No Topic</h1>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rokaskrygeris/KETSpace/resources/views/topics/show.blade.php ENDPATH**/ ?>