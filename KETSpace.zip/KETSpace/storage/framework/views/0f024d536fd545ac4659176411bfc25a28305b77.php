<?php $__env->startSection('content'); ?>
    <div class="d-flex" id="wrapper">
        <?php if(Auth::user()): ?>
            <?php if(Auth::user()->role == 'admin'): ?>
                <?php echo $__env->make('adminpanel.adminSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-md-6 mt-4">
                    <h3 class="page-title">Topics</h3>
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body mb-2">
                                <h5 class="card-title"><?php echo e($topic->title); ?></h5>
                                <a href="<?php echo e(route('topics.show', $topic->id)); ?>" class="inline_block btn btn-primary">Go
                                    To Quiz</a>
                                <?php if(Auth::user()): ?>
                                    <?php if(Auth::user()->role == 'admin'): ?>
                                        <a href="<?php echo e(route('topics.edit', $topic->id)); ?>"
                                           class="inline_block btn btn-warning">Edit</a>
                                        <form class="inline_block" action="<?php echo e(route('topics.destroy', $topic->id)); ?>"
                                              method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-xs btn-danger" type="submit">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rokaskrygeris/KETSpace/resources/views/topics/index.blade.php ENDPATH**/ ?>