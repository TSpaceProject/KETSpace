<?php $__env->startSection('content'); ?>

    <div class="d-flex" id="wrapper">
        <div class="container">
            <?php if($result): ?>
                <div class="row">
                    <div class="col-md-12 mt-4">
                        <table class="table table-bordered table-striped">
                            <tr>
                                <th>User</th>
                                <td><?php echo e($result->user->name); ?> (<?php echo e($result->user->email); ?>)</td>
                            </tr>
                            <tr>
                                <th>Date</th>
                                <td><?php echo e($result->created_at); ?></td>
                            </tr>
                            <tr>
                                <th>Score</th>
                                <td><?php echo e($result->correct_answers); ?>/<?php echo e($result->questions_count); ?></td>
                            </tr>
                        </table>
                        <table class="table table-bordered table-striped">
                            <?php $n = 0 ?>
                            <?php $__currentLoopData = $result->topic->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $n++ ?>
                                <tr class="test-option-false">
                                    <th style="width: 10%">Question #<?php echo e($n); ?></th>
                                    <th><?php echo e($question->question_text); ?></th>
                                </tr>
                                <tr>
                                    <td>Options</td>
                                    <td>
                                        <ul>
                                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($option->correct == 1): ?>
                                                    <li style="font-weight: bold;"><?php echo e($option->option); ?>

                                                        <em>(correct answer)</em>
                                                        <?php $__currentLoopData = $result->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($user_option->option_id == $option->id): ?>
                                                                <em>(your answer)</em>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                                <?php else: ?>
                                                    <li>
                                                        <?php echo e($option->option); ?>

                                                        <?php $__currentLoopData = $result->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($user_option->option_id == $option->id): ?>
                                                                <em style="font-weight: bold;">(your answer)</em>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <?php else: ?>
                <h1>No Result</h1>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rokaskrygeris/KETSpace/resources/views/results/show.blade.php ENDPATH**/ ?>